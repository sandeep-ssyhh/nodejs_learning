import { Component } from '@angular/core';
import { FileServiceService } from './file-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'task';
  fileToUpload = null;
  constructor(private fileServiceService: FileServiceService) {
  }
  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
  }
  uploadFileToActivity() {
    this.fileServiceService.postFile(this.fileToUpload).subscribe(response => {
      // do something, if upload success
      console.log('response : ', response);
      alert('File Uploaded Successfully');
    }, error => {
      console.log(error);
      alert('Error in File Upload');
    });
  }
}
