import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { ,Headers } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FileServiceService {

  constructor(private http: HttpClient) { }
  postFile(fileToUpload: File) {
    const endpoint = 'your-destination-url';
    const formData: FormData = new FormData();
    formData.append('jfile', fileToUpload, fileToUpload.name);
    return this.http.post('http://localhost:4200/api/reference-document-upload', formData, { headers: new HttpHeaders() });
  }
}
